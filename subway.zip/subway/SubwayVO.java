package vo;

public class SubwayVO {
	private String line;
	private String time;
	private int ride;
	private int takeoff;
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getRide() {
		return ride;
	}
	public void setRide(int ride) {
		this.ride = ride;
	}
	public int getTakeoff() {
		return takeoff;
	}
	public void setTakeoff(int takeoff) {
		this.takeoff = takeoff;
	}
	
}
