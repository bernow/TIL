
package my.spring.springedu;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dao.SubwayDAO;
import vo.SubwayVO;

@Controller
public class SubwayController {

	@Autowired
	SubwayDAO dao;

	@RequestMapping("/subway1")
	ModelAndView selectData1() {
		ModelAndView mav = new ModelAndView();
		List<SubwayVO> list = dao.select1();
		mav.addObject("list1", list);
		mav.setViewName("subwayview");
		return mav;
	}

	@RequestMapping("/subway2")
	ModelAndView selectData2() {
		ModelAndView mav = new ModelAndView();
		List<SubwayVO> list = dao.select1();
		mav.addObject("list2", list);
		mav.setViewName("subwayview");
		return mav;
	}

	@RequestMapping("/subway3")
	ModelAndView selectData3() {
		ModelAndView mav = new ModelAndView();
		List<SubwayVO> list = dao.select1();
		mav.addObject("list3", list);
		mav.setViewName("subwayview");
		return mav;
	}

	@RequestMapping("/subway4")
	ModelAndView selectData4() {
		ModelAndView mav = new ModelAndView();
		List<SubwayVO> list = dao.select1();
		mav.addObject("list4", list);
		mav.setViewName("subwayview");
		return mav;
	}

}
